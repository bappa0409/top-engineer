
<!--begin::Jquery-->
<script src="<?php echo e(asset('assets/admin/plugins/jquery/jquery-3.6.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/plugins/jquery-ui/jquery-ui.js')); ?>"></script>
<!--end::Jquery-->

<!--begin::Datatables-->
<script src="<?php echo e(asset('assets/admin/plugins/datatables/datatables.js')); ?>"></script>
<!--end::Datatables-->

<!--begin::Select2 & Sweet Alert-->
<script src="<?php echo e(asset('assets/admin/plugins/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/plugins/sweetalert2/sweetalert2.js')); ?>"></script>
<!--end::Select2 & Sweet Alert-->

<!--Start Date Time Picker With Moment-->
<script src="<?php echo e(asset('assets/admin/plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<!--End Date Time Picker-->

<script src="<?php echo e(asset('assets/admin/js/app.js')); ?>?v_<?php echo e(date("h_i")); ?>"></script>


<!--begin::Custom-->
<script src="<?php echo e(asset('assets/admin/js/custom.js')); ?>?v_<?php echo e(date("h_i")); ?>"></script>
<!--end::Custom--><?php /**PATH C:\xampp\htdocs\top-engineer\resources\views/include/js.blade.php ENDPATH**/ ?>