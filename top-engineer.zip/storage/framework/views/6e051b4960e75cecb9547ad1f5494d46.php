<div id="topbar" class="fixed-top d-flex align-items-center">
    <!-- ======= Top Bar ======= -->
    <div class="container d-flex align-items-center justify-content-center justify-content-md-between">
        <div class="contact-info d-flex align-items-center ">

            <i class="bi bi-geo-alt-fill phone-icon d-none d-lg-block"></i> <a class="d-none d-lg-block">Kosovska 17,
                Beograd-stari grad, Serbia</a>
            <i class="bi bi-phone-fill   phone-icon d-none d-md-block"></i> <a class="d-none d-md-block"
                href="tel:+3 811 142 20 62 1">+3 811 142 20 62 1</a>
            <!-- <i class="bi bi-phone-fill phone-icon">	  </i>  				<a href="tel:+1 781 435 74 26">+1 781 435 74 26</a>  -->
            <i class="bi bi-envelope-fill phone-icon"></i> <a
                href="mailto:info@top-engineer.com">info@top-engineer.com</a>
        </div>

        <!-- =
		<div class="cta d-none d-md-block">
			<a href="https://wa.me/message/NJAV34FHKK47G1">WhatsApp</a>
		</div>  
      == -->
    </div>
</div>
<header id="header" class="fixed-top d-flex align-items-center">
    <!-- ======= Header ======= -->
    <div class="container d-flex align-items-center justify-content-between">
        <a href="/" class="logo"><img src="/local/templates/top_com/assets/img/logo2.png" alt="Topengineer logo"
                class=""></a>

        <div class=" d-xs-block  d-lg-none socializer a sr-48px sr-squircle sr-float sr-icon-grey sr-bg-none">
            <span class="sr-linkedin"> <a href="https://www.linkedin.com/company/top-engineer/" target="_blank"
                    title="LinkedIn"> <i class="bi bi-linkedin"> </i></a></span>
            <span class="sr-whatsapp"> <a href="https://wa.me/message/NJAV34FHKK47G1" target="_blank" title="WhatsApp">
                    <i class="bi bi-whatsapp"> </i></a></span>
            <span class="sr-telegram"> <a href="https://telegram.me/TopEngineerChat" target="_blank" title="Telegram">
                    <i class="bi bi-telegram"> </i></a></span>
            <span class="sr-skype"> <a href="skype:perezhog" target="_blank" title="Skype"> <i class="bi bi-skype">
                    </i></a></span>
        </div>
        <!-- ======= END  Horizontal social networks ======= -->
        <nav id="navbar" class="navbar">

            <ul>
                <!-- Первый уровень меню -->
                <li>
                    <a href="/" class="nav-link scrollto active">
                        HOME </a>
                </li>
                <!-- Первый уровень меню -->
                <li>
                    <a href="/steel-detailing/" class="nav-link scrollto ">
                        STEEL DETALING </a>
                </li>
                <!-- Первый уровень меню -->
                <li>
                    <a href="/rebar-detailing/" class="nav-link scrollto ">
                        REBAR DETALING </a>
                </li>
                <!-- Первый уровень меню -->
                <li>
                    <a href="https://top-engineer.com/#bim-modeling/" class="nav-link scrollto ">
                        BIM MODELING </a>
                </li>
                <!-- Второй уровень меню с выпадающим списком -->
                <li class="dropdown">
                    <a href="/metalib/" class="">
                        <span>METALIB</span>
                        <i class="bi bi-chevron-down"></i>
                    </a>
                    <ul>
                        <li class="dropdown">
                            <a href="/metalib/introduction/">
                                Introduction <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a
                                        href="/metalib/introduction/1-1-who-can-benefit-from-studying-present-guidelines/">
                                        1.1 Who can benefit from studying present guidelines </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a
                                        href="/metalib/introduction/1-2-tekla-structures-features-map-and-application-fields/">
                                        1.2 Tekla Structures features map and application fields </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/introduction/1-3-field-cases-executed-in-tekla-structures/">
                                        1.3 Field cases executed in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a
                                        href="/metalib/introduction/1-4-pc-system-requirements-for-using-the-tekla-structures/">
                                        1.4 PC System requirements for using the Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a
                                        href="/metalib/introduction/1-5-where-to-download-the-tekla-structures-training-version/">
                                        1.5 Where to download the Tekla Structures training version </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/introduction/1-6-tekla-structures-installation-tips/">
                                        1.6 Tekla Structures installation tips </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/introduction/1-7-tekla-structures-localization-packages/">
                                        1.7 Tekla Structures localization packages </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/introduction/1-8-launching-tekla-structures/">
                                        1.8 Launching Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/first-step/">
                                First step * <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/first-step/2-1-1-creating-a-new-project/">
                                        2.1.1 Creating a new project </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/first-step/2-1-2-the-main-menu-elements-in-tekla-structures/">
                                        2.1.2 The main menu elements in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a
                                        href="/metalib/first-step/2-1-3-minimizing-maximizing-the-model-in-tekla-structures/">
                                        2.1.3 Minimizing/ maximizing the model in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/first-step/2-1-4-rotating-a-model-in-tekla-structures/">
                                        2.1.4 Rotating a model in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a
                                        href="/metalib/first-step/2-1-5-creating-standard-views-in-the-model-by-xy-xz-zy-axes-in-tekla-structures/">
                                        2.1.5 Creating standard views in the model by XY, XZ, ZY axes in Tekla
                                        Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/first-step/2-1-6-arranging-switching-views-in-tekla-structures/">
                                        2.1.6 Arranging/switching views in &nbsp;Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a
                                        href="/metalib/first-step/2-1-7-switching-to-the-view-plane-in-tekla-structures/">
                                        2.1.7 Switching to the view plane in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/first-step/2-1-8-dragging-the-view-plane-in-tekla-structures/">
                                        2.1.8 Dragging the view plane in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/the-grid-tool/">
                                The “Grid” tool <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-grid-tool/2-2-the-grid-tool-in-tekla-structures/">
                                        2.2 The “Grid” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a
                                        href="/metalib/the-grid-tool/2-2-2-the-modify-button-of-the-tekla-structures-grid-properties/">
                                        2.2.2 The “Modify” button of the Tekla Structures “Grid properties” </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a
                                        href="/metalib/the-grid-tool/2-2-3-creating-a-complementary-grid-in-tekla-structures/">
                                        2.2.3 Creating a complementary grid in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a
                                        href="/metalib/the-grid-tool/2-2-4-saving-the-current-grid-settings-in-tekla-structures/">
                                        2.2.4 Saving the current grid settings in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a
                                        href="/metalib/the-grid-tool/2-2-5-uploading-the-saved-grids-configurations-into-other-tekla-structures-models/">
                                        2.2.5 Uploading the saved grids configurations into other Tekla Structures
                                        models </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-grid-tool/2-2-6-setting-out-the-snapping-tools/">
                                        2.2.6 Setting out the snapping tools </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-grid-tool/2-2-7-moving-grids-in-tekla-structures/">
                                        2.2.7 Moving grids in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-grid-tool/2-2-8-copying-a-grid-in-tekla-structures/">
                                        2.2.8 Copying a grid in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-grid-tool/2-2-9-the-radial-grid-tool-in-tekla-structures/">
                                        2.2.9 The “Radial grid” tool in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/steel-columns/">
                                Steel columns <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-steel-columns-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.3 Steel columns in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-1-creating-columns-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.3.1 Creating columns in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-2-the-column-properties-menu-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.3.2 The “Column Properties” menu in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-3-the-cancel-and-close-buttons-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.3.3 The “Cancel” and “Close” buttons in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-4-the-apply-button-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.3.4 The “Apply” button in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-5-the-ok-button-and-its-main-distinctions-from-the-cancel/"
                                        style="color: #aaa !important;">
                                        2.3.5 The “Ok” button and its main distinctions from the “Cancel” </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-6-the-get-button-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.3.6 The “Get” button in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-7-the-modify-button-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.3.7 The “Modify” button in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-8-the-position-of-a-column-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.3.8 The position of a column in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-9-the-deforming-tool-of-the-column-properties/"
                                        style="color: #aaa !important;">
                                        2.3.9 The “Deforming” tool of the “Column Properties” </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-10-simultaneously-setting-up-particular-attributes-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.3.10 Simultaneously setting up particular attributes in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-11-the-save-settings-box-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.3.11 The “Save settings” box in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-12-the-user-defined-attributes-of-the-column/"
                                        style="color: #aaa !important;">
                                        2.3.12 The “User-defined attributes” of the “Column </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/steel-columns/2-3-13-the-mini-toolbar-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.3.13 The “Mini toolbar” in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/snapping-tools-selecting-tools/">
                                Snapping tools/ Selecting tools/ <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/snapping-tools-selecting-tools/2-4-snapping-tools-selecting-tools-object-types-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.4 Snapping tools/ Selecting tools/ Object types in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/snapping-tools-selecting-tools/2-4-1-selecting-and-ignoring-objects-by-type/"
                                        style="color: #aaa !important;">
                                        2.4.1 Selecting and ignoring objects by type </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/snapping-tools-selecting-tools/2-4-2-snapping-an-object-to-the-geometry/"
                                        style="color: #aaa !important;">
                                        2.4.2 Snapping an object to the geometry </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/snapping-tools-selecting-tools/2-4-3-snapping-to-the-object-reference-corner-points/"
                                        style="color: #aaa !important;">
                                        2.4.3 Snapping to the object reference/corner points </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/snapping-tools-selecting-tools/2-4-4-selecting-objects-by-frame-in-the-left-to-right-and-right-to-left-direction/"
                                        style="color: #aaa !important;">
                                        2.4.4 Selecting objects by frame in the left-to-right and right-to-left
                                        direction </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/the-construction-geometry/">
                                The Construction geometry <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-construction-geometry/2-5-the-construction-geometry-tools-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.5 The “Construction geometry” tools in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-construction-geometry/2-5-1-the-points-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.5.1 The “Points” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-construction-geometry/2-5-2-the-construction-line-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.5.2 The “Construction line” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-construction-geometry/2-5-3-the-orthogonal-regime-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.5.3 The &amp;quot;Orthogonal regime&amp;quot; in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-construction-geometry/2-5-4-the-construction-circle-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.5.4 The &amp;quot;Construction circle&amp;quot; tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-construction-geometry/2-5-5-dividing-a-construction-line-into-a-specified-number-of-segments/"
                                        style="color: #aaa !important;">
                                        2.5.5 Dividing a construction line into a specified number of segments </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-construction-geometry/2-5-6-the-construction-plane-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.5.6 The “Construction plane” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-construction-geometry/2-5-7-other-construction-geometry-tools-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.5.7 Other construction geometry tools in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/the-contour-plate/">
                                The Contour plate <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-the-contour-plate-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.6 The “Contour plate” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-1-create-contour-plate-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.6.1 Create contour plate in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-2-the-contour-plate-properties-menu-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.6.2 The “Contour plate Properties” menu in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-3-selecting-a-point-from-the-contour-plate-surface-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.6.3 Selecting a point from the contour plate surface in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-4-chamfers-of-a-contour-plate-object-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.6.4 Chamfers of a contour plate object in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-5-selecting-a-group-of-points-at-a-contour-plate-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.6.5 Selecting a group of points at a contour plate in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-6-moving-a-group-of-points-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.6.6 Moving a group of points in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-7-adding-and-deleting-points-at-from-the-contour-plate-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.6.7 Adding and deleting points at/from the contour plate in Tekla Structures
                                    </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-8-creating-a-base-plate/"
                                        style="color: #aaa !important;">
                                        2.6.8 Creating a base plate </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-9-the-cylindrical-bend-plate-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.6.9 The “Cylindrical bend plate” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-10-the-conical-bent-plate-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.6.10 The “Conical bent plate”tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-11-the-stand-alone-bent-plate-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.6.11 The “Stand-alone bent plate” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-contour-plate/2-6-12-the-lofted-plate-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.6.12 The “Lofted plate” tool in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/the-steel-beam-tool/">
                                The Steel Beam tool <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-steel-beam-tool/2-7-the-steel-beam-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.7 The “Steel Beam” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-steel-beam-tool/2-7-1-creating-beams-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.7.1 Creating beams in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-steel-beam-tool/2-7-2-distinctions-between-a-column-and-a-beam-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.7.2 Distinctions between a column and a beam in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-steel-beam-tool/2-7-3-transforming-a-beam-into-a-column-and-vice-versa/"
                                        style="color: #aaa !important;">
                                        2.7.3 Transforming a beam into a column and vice versa </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-steel-beam-tool/2-7-4-the-polybeam-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.7.4 The “Polybeam” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-steel-beam-tool/2-7-5-curved-beam-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.7.5 Curved beam in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-steel-beam-tool/2-7-6-the-twin-profile-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.7.6 The “Twin profile” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-steel-beam-tool/2-7-7-the-split-and-combine-tools-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.7.7 The “Split” and “Combine” tools in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-steel-beam-tool/2-7-8-the-orthogonal-beam-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.7.8 The “Orthogonal beam” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-steel-beam-tool/2-7-9-the-spiral-beam-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.7.9 The “Spiral beam” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-steel-beam-tool/2-7-10-the-item-tool-ifc-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.7.10 The “Item” tool /IFC in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/moving-objects/">
                                Moving objects <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/moving-objects/2-8-moving-objects-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.8 Moving objects in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/moving-objects/2-8-1-nbsp-moving-objects-using-the-ctrl-m-hotkey-combination/"
                                        style="color: #aaa !important;">
                                        2.8.1 Moving objects using the Ctrl+M hotkey combination </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/moving-objects/2-8-2-the-move-linear-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.8.2 The “Move Linear” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/moving-objects/2-8-3-the-move-special-rotate-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.8.3 The “Move Special - Rotate” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/moving-objects/2-8-4-the-move-special-mirror-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.8.4 The “Move Special - Mirror” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/moving-objects/2-8-5-the-move-special-to-another-plane-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.8.5 The “Move Special- To another plane” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/moving-objects/2-8-6-the-move-special-to-another-object-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.8.6 The “Move Special - To another object” tool in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/the-copy-tool/">
                                The Copy tool <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-copy-tool/2-9-the-copy-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.9 The “Copy” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-copy-tool/2-9-1-the-copy-tool-by-using-the-ctrl-c-hotkey-combination-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.9.1 The “Copy” tool by using the Ctrl+C hotkey combination in Tekla Structures
                                    </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-copy-tool/2-9-2-the-copy-special-linear-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.9.2 The “Copy Special - Linear” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-copy-tool/2-9-3-the-copy-special-rotate-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.9.3 The “Copy Special - Rotate” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-copy-tool/2-9-4-the-copy-special-mirror-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.9.4 The “Copy Special-Mirror” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-copy-tool/2-9-5-the-copy-special-to-another-plane-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.9.5 The “Copy Special - to another plane” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-copy-tool/2-9-6-the-copy-special-to-another-object-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.9.6 The “Copy Special - To another object” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-copy-tool/2-9-7-the-phase-manager-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.9.7 The “Phase manager” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-copy-tool/2-9-8-the-copy-from-another-model-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.9.8 The “Copy from another model” tool in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/the-added-material-tools/">
                                The added material tools <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-added-material-tools/2-10-the-added-material-tools-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.10 The added material tools in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-added-material-tools/2-10-1-the-cut-part-with-line-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.10.1 The “Cut part with line” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-added-material-tools/2-10-2-the-fit-part-end-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.10.2 The “Fit part end” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-added-material-tools/2-10-3-the-cut-object-with-polygon-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.10.3 The “Cut object with polygon” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-added-material-tools/2-10-4-the-cut-object-with-part-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.10.4 The “Cut object with part” tool in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/the-chamfer-tool/">
                                The Chamfer tool <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-chamfer-tool/2-11-the-chamfer-tool/"
                                        style="color: #aaa !important;">
                                        2.11 The “Chamfer” tool </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-chamfer-tool/2-11-1-the-create-chamfer-for-part-edge-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.11.1 The “Create chamfer - For part edge” in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-chamfer-tool/2-11-2-the-create-chamfer-for-part-corner-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.11.2 The “Create Chamfer - For part corner” tool in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/the-bolts-tool/">
                                The Bolts tool <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-bolts-tool/2-12-the-bolts-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.12 The “Bolts” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-bolts-tool/2-12-1-the-bolted-joints-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.12.1 The bolted joints in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/the-measure-tools/">
                                The Measure tools <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-measure-tools/2-13-the-measure-tools-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.13 The “Measure” tools in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-measure-tools/2-13-1-the-measure-vertical-distance-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.13.1 The “Measure - Vertical distance” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-measure-tools/2-13-2-the-measure-horizontal-distance-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.13.2 The “Measure - Horizontal distance” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-measure-tools/2-13-3-the-measure-distance-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.13.3 The “Measure - Distance” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-measure-tools/2-13-4-the-measure-bolt-spacing-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.13.4 The “Measure - Bolt spacing” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-measure-tools/2-13-5-the-measure-angle-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.13.5 The “Measure -Angle” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-measure-tools/2-13-6-the-measure-arc-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.13.6 The “Measure -Arc” tool in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/the-surface-treatment/">
                                The Surface treatment <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-surface-treatment/2-14-the-surface-treatment-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.14 The “Surface treatment” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-surface-treatment/2-14-1-the-surfaces-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.14.1 The “Surfaces” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-surface-treatment/2-14-2-the-surface-treatment-to-part-face-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.14.2 The “ Surface treatment to part face” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-surface-treatment/2-14-3-the-surface-treatment-to-all-faces-of-part-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.14.3 The “ Surface treatment to all faces of part” tool in Tekla Structures
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/views/">
                                Views <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/views/2-15-views-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.15 Views in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/views/2-15-1-the-basic-view-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.15.1 The “Basic View” in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/views/2-15-2-selecting-views-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.15.2 Selecting views in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/views/2-15-3-the-view-depth-up-down-field/"
                                        style="color: #aaa !important;">
                                        2.15.3 The “View depth Up/ Down” field </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/views/2-15-4-the-workplane-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.15.4 The workplane in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/views/2-15-5-saving-views-the-view-list-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.15.5 Saving views / The View list in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/views/2-15-6-creating-views-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.15.6 Creating views in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/views/2-15-7-the-hide-tool/" style="color: #aaa !important;">
                                        2.15.7 The “Hide” tool </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/views/2-15-8-the-show-only-selected-tool/"
                                        style="color: #aaa !important;">
                                        2.15.8 The “Show only selected” tool </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/views/2-15-9-the-show-with-exact-lines-tool/"
                                        style="color: #aaa !important;">
                                        2.15.9 The “Show with exact lines” tool </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/views/2-15-10-the-view-properties-window-the-display-button/"
                                        style="color: #aaa !important;">
                                        2.15.10 The &amp;quot;View properties&amp;quot; window / The
                                        &amp;quot;Display&amp;quot; button </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/views/2-15-11-the-view-settings-menu-display-button/"
                                        style="color: #aaa !important;">
                                        2.15.11 The “View Settings” menu / “Display” button/ </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/the-weld-tool/">
                                The Weld tool <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-weld-tool/2-16-the-weld-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.16 The “Weld” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-weld-tool/2-16-1-the-create-weld-between-parts-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.16.1 The “Create weld between parts” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-weld-tool/2-16-2-the-main-component-of-an-assembly-in-the-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.16.2 The main component of an assembly in the Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-weld-tool/2-16-3-the-create-polygon-weld-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.16.3 The “Create polygon weld” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-weld-tool/2-16-4-the-convert-to-polygon-weld-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.16.4 The “Convert to polygon weld” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-weld-tool/2-16-5-the-create-weld-to-part-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.16.5 The “Create weld to part” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-weld-tool/2-16-6-the-prepare-part-for-welding-with-another-part-tool-intekla-structures/"
                                        style="color: #aaa !important;">
                                        2.16.6 The “Prepare part for welding with another part” tool inTekla Structures
                                    </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-weld-tool/2-16-7-the-prepare-part-for-welding-with-another-part-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.16.7 The “Prepare part for welding with another part” tool in Tekla Structures
                                    </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/the-weld-tool/2-16-8-the-welding-assignment/"
                                        style="color: #aaa !important;">
                                        2.16.8 The Welding assignment </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/non-uniform-beams/">
                                Non-Uniform beams <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/non-uniform-beams/2-17-non-uniform-beams-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.17 Non-Uniform beams in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/non-uniform-beams/2-17-1-non-uniform-beams-created-of-a-profile-in-the-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.17.1 Non-uniform beams created of a profile in the Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/non-uniform-beams/2-17-2-welded-uniform-cross-section-beams-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.17.2 Welded uniform cross-section beams in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/non-uniform-beams/2-17-3-welded-non-uniform-cross-section-beams-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.17.3 Welded non-uniform cross-section beams in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/non-uniform-beams/2-17-4-the-sin-beams-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.17.4 The SIN beams in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/concrete-pour/">
                                Concrete pour <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-the-concrete-pour-modeling-tools-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18 The “Concrete pour” modeling tools in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-1-the-concrete-column-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.1 The “Concrete column” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-2-the-add-to-remove-from-cast-unit-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.2 The “Add to/Remove from cast unit” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-3-the-concrete-beam-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.3 The “Concrete beam” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-4-the-strip-footing-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.4 The “Strip footing” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-5-the-concrete-panel-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.5 The “Concrete panel” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-6-the-concrete-polybeam-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.6 The “Concrete polybeam” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-7-the-concrete-slab-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.7 The “Concrete slab” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-8-add-to-remove-from-part-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.8 “Add to/Remove from part” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-9-the-spiral-beam-tool-in-the-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.9 The “Spiral beam” tool in the Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-10-the-lofted-plate-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.10 The “Lofted plate” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-11-the-floor-layout-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.11 The “Floor layout” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-12-the-wall-layout-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.12 The “Wall layout” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/concrete-pour/2-18-14-the-pour-view-and-pour-break-tools-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.18.14 The “Pour view” and “Pour break” tools in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="/metalib/rebar-modeling/">
                                Rebar modeling <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/rebar-modeling/2-19-rebar-modeling-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.19 Rebar modeling in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/rebar-modeling/2-19-1-the-single-bar-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.19.1 The “Single bar” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/rebar-modeling/2-19-2-the-bar-group-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.19.2 The “Bar group” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/rebar-modeling/2-19-3-the-rebar-shape-catalog-tool-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.19.3 The “Rebar shape catalog” tool in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/rebar-modeling/2-19-4-the-create-rebars-by-point-input-tool/"
                                        style="color: #aaa !important;">
                                        2.19.4 The “Create rebars by point input” tool </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/rebar-modeling/2-19-5-the-group-ungroup-tools-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.19.5 The “Group”/ “Ungroup” tools in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/rebar-modeling/2-19-6-the-rebar-splice-tool-in/"
                                        style="color: #aaa !important;">
                                        2.19.6 The “Rebar Splice” tool in </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/rebar-modeling/2-19-7-rebar-sets-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.19.7 Rebar sets in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/rebar-modeling/2-19-8-the-reinforcement-mesh-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.19.8 The reinforcement mesh in Tekla Structures </a>
                                </li>
                                <!-- Третий уровень меню -->
                                <li>
                                    <a href="/metalib/rebar-modeling/2-19-9-prestressed-reinforcement-in-tekla-structures/"
                                        style="color: #aaa !important;">
                                        2.19.9 Prestressed reinforcement in Tekla Structures </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <!-- Первый уровень меню -->
                <li>
                    <a href="/consulting/" class="nav-link scrollto ">
                        CONSULTING </a>
                </li>
                <!-- Первый уровень меню -->
                <li>
                    <a href="/portfolio/" class="nav-link scrollto ">
                        OUR PROJECTS </a>
                </li>
                <!-- Первый уровень меню -->
                <li>
                    <a href="/#contact/" class="nav-link scrollto ">
                        CONTACT US </a>
                </li>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav>
    </div>
</header><?php /**PATH C:\xampp\htdocs\top-engineer\resources\views\frontend\include\header.blade.php ENDPATH**/ ?>