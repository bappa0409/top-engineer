<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    
<!--begin::Head-->
<head>
    <!--begin::Meta-->
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="title" content="<?php echo $__env->yieldContent('title'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="Permissions-Policy" content="interest-cohort=()">
    <?php echo $__env->yieldContent('meta'); ?>
    <!--end::Meta-->

    <!--begin::Title-->
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!--end::Title-->

    <!-- App favicon -->
    <link rel="shortcut icon"
    href="<?php echo e(app('setting')->favicon ? asset('upload/setting/logo/' . app('setting')->favicon) : asset('assets/dist/img/favicon.png')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/style.css')); ?>">
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<!--end::Head-->

<body>
    <!--begin::Wrapper-->
    <div class="wrapper">

        <?php echo $__env->make('include.frontend.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


        <!--begin::Content-->
        <?php echo $__env->yieldContent('website_content'); ?>
        <!--end::Content-->

        
        <!--begin::Footer-->
        <?php echo $__env->make('include.frontend.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--end::Footer-->

    </div>
    <!--end::Wrapper-->


    <script src="<?php echo e(asset('assets/frontend/js/app.js')); ?>?v_<?php echo e(date("h_i")); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\top-engineer\resources\views\layouts\website.blade.php ENDPATH**/ ?>