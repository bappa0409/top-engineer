<nav class="navbar navbar-expand navbar-light navbar-bg">
    <a class="sidebar-toggle js-sidebar-toggle">
        <i class="hamburger align-self-center"></i>
    </a>

    <!-- Go Website Button -->
    <a href="<?php echo e(url('/')); ?>" target="_blank" class="btn btn-outline-primary d-flex align-items-center me-3">
        <i data-feather="globe" class="me-1"></i>
        Go Website
    </a>

    <div class="navbar-collapse collapse">
        <ul class="navbar-nav navbar-align">
            <li class="nav-item dropdown">
                <a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#"
                    data-bs-toggle="dropdown">
                    <i class="align-middle" data-feather="settings"></i>
                </a>

                <a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#"
                    data-bs-toggle="dropdown">
                    <img src="<?php echo e(Auth::user()->profile_photo_path ? asset('upload/profile/'.Auth::user()->profile_photo_path) : asset('assets/admin/img/avatar.jpg')); ?>" class="avatar img-fluid rounded me-1" alt="<?php echo e(Auth::user()->name ? Auth::user()->name : ''); ?>" />
                    <span class="text-dark"><?php echo e(Auth::user()->name ? Auth::user()->name : ''); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end">
                    <a class="dropdown-item" href="<?php echo e(route('admin.profile.show')); ?>"><i class="align-middle me-1"
                            data-feather="user"></i> Profile</a>

                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item"
                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="align-middle me-1" data-feather="log-out"></i>Log out
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </a>
                </div>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\top-engineer\resources\views/include/header.blade.php ENDPATH**/ ?>