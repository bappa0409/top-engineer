<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<!--begin::Head-->
<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/admin/img/icons/icon-48x48.png')); ?>" />

    <?php echo $__env->make('include.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<!--end::Head-->

<div class="wrapper">

    <!--begin::Aside menu-->
    <?php echo $__env->make('include.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!--end::Aside menu-->

    <div class="main">

        <!--begin::Aside menu-->
        <?php echo $__env->make('include.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--end::Aside menu-->

        <!--begin::Content-->
        <main class="content">
            <div class="container-fluid p-0">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
        <!--end::Content-->

        <!--begin::Footer-->
        <?php echo $__env->make('include.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!--end::Footer-->
    </div>

    <?php echo $__env->make('include.js', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</div>

</html>
<?php /**PATH C:\xampp\htdocs\top-engineer\resources\views\layouts\app.blade.php ENDPATH**/ ?>