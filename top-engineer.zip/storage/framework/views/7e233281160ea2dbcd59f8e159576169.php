<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<section class="admin-visitor-area">
    <div class="container-fluid">
        

        <div class="row g-4 mb-4">
            <!-- Total Projects -->
            <div class="col-md-3 col-sm-6">
                <div class="card shadow-sm border-0 rounded-3 text-white bg-primary h-100">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div>
                            <h6 class="card-title text-white mb-1">Total Projects</h6>
                            <h3 class="mb-0 text-white"><?php echo e($totalProjects ?? 0); ?></h3>
                        </div>
                        <div class="display-6 opacity-50">
                            <i data-feather="folder"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Published Projects -->
            <div class="col-md-3 col-sm-6">
                <div class="card shadow-sm border-0 rounded-3 text-white bg-success h-100">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div>
                            <h6 class="card-title text-white mb-1">Published Projects</h6>
                            <h3 class="mb-0 text-white"><?php echo e($publishedProjects ?? 0); ?></h3>
                        </div>
                        <div class="display-6 opacity-50">
                            <i data-feather="check-circle"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Draft Projects -->
            <div class="col-md-3 col-sm-6">
                <div class="card shadow-sm border-0 rounded-3 text-white bg-secondary h-100">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div>
                            <h6 class="card-title text-white mb-1">Draft Projects</h6>
                            <h3 class="mb-0 text-white"><?php echo e($draftProjects ?? 0); ?></h3>
                        </div>
                        <div class="display-6 opacity-50">
                            <i data-feather="edit-2"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Total Contacts -->
            <div class="col-md-3 col-sm-6">
                <div class="card shadow-sm border-0 rounded-3 text-white bg-warning h-100">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div>
                            <h6 class="card-title text-white mb-1">Total Contacts</h6>
                            <h3 class="mb-0 text-white"><?php echo e($totalContacts ?? 0); ?></h3>
                        </div>
                        <div class="display-6 opacity-50">
                            <i data-feather="users"></i>
                        </div>
                    </div>
                </div>
            </div>

        </div>


        <!-- Recent Projects Table -->
        <div class="card mb-4">
            <div class="card-header">
                <h4 class="mb-0">Recent Projects</h4>
            </div>
            <div class="card-body">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Title</th>
                            <th>Status</th>
                            <th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recentProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($project->title); ?></td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->status == 'published'): ?>
                                        <span class="badge bg-success">Published</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Draft</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td><?php echo e($project->created_at->format('d M Y')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center">No projects found</td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Recent Contacts Table -->
        <div class="card mb-4">
            <div class="card-header">
                <h4 class="mb-0">Recent Contacts</h4>
            </div>
            <div class="card-body">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Message</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recentContacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($contact->name); ?></td>
                                <td><?php echo e($contact->email); ?></td>
                                <td><?php echo e($contact->mobile ?? 'N/A'); ?></td>
                                <td><?php echo e(\Str::limit($contact->message, 50)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center">No contacts found</td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\top-engineer\resources\views\pages\dashboard.blade.php ENDPATH**/ ?>