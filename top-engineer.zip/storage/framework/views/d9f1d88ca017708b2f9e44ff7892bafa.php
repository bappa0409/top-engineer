<?php $__env->startSection('title', 'Contact List'); ?>

<?php $__env->startSection('content'); ?>

   <!--begin::Validation Message-->
   <?php echo $__env->make('include.validation-message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
   <!--end::Validation Message-->

    <section class="admin-visitor-area">
        <div class="card mb-3">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col-6">
                        <h1 class="mb-0">Contact List</h1>
                    </div>
                    <div class="col-6 text-end">
                        <a href="javascript:void(0)" data-route="<?php echo e(route('admin.contacts.multi_destroy')); ?>" class="btn btn-danger delete-all">Bulk Delete</a>
                    </div>
                </div>
            </div>
           
            <div class="card-body">
                <?php echo e($dataTable->table([], true)); ?>

            </div>
        </div>
    </section>
    
    <!-- Modal -->
    <div class="modal fade" id="contactModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Contact Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Name:</strong> <span id="contact-name"></span></p>
                    <p><strong>Email:</strong> <span id="contact-email"></span></p>
                    <p><strong>Mobile:</strong> <span id="contact-mobile"></span></p>
                    <p><strong>Message:</strong> <span id="contact-message"></span></p>
                    <p><strong>Created At:</strong> <span id="contact-created"></span></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo $dataTable->scripts(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\top-engineer\resources\views\pages\contact\index.blade.php ENDPATH**/ ?>