<!--begin::Jquery-->
<script src="<?php echo e(asset('assets/frontend/vendor/jquery/jquery-3.6.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/vendor/jquery-ui/jquery-ui.js')); ?>"></script>
<!--end::Jquery-->


<!--begin::Sweet Alert-->
<script src="<?php echo e(asset('assets/frontend/vendor/sweetalert2/sweetalert2.js')); ?>"></script>
<!--end::Sweet Alert-->

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('assets/frontend/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/vendor/imagesloaded/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>

<!-- Main JS File -->
<script src="<?php echo e(asset('assets/frontend/js/app.js')); ?>?v_<?php echo e(date("h_i")); ?>"></script>


<!--begin::Custom-->
<script src="<?php echo e(asset('assets/frontend/js/custom.js')); ?>?v_<?php echo e(date("h_i")); ?>"></script>
<!--end::Custom-->


<?php /**PATH C:\xampp\htdocs\top-engineer\resources\views/frontend/include/js.blade.php ENDPATH**/ ?>