<footer id="footer">
    <div style="width: 100%">
        <iframe loading="lazy" width="100%" height="400" frameborder="1" scrolling="no" marginheight="0" marginwidth="0"
            src="https://maps.google.com/maps?width=520&amp;height=200&amp;hl=en&amp;q=Kosovska%2017,%20Beograd-stari%20grad,%20Serbia%20Serbia+(top-engineer.com)&amp;t=k&amp;z=19&amp;ie=UTF8&amp;iwloc=B&amp;output=embed">
            <a href="https://www.gps.ie/marine-gps/">navigation gps</a>
        </iframe>
    </div>

    <div class="container">
        <div class="copyright">
        </div>
        <div class="credits">
            <a href="https://top-engineer.com/upload/Poslovnik.pdf">Politika poslovanja</a>
            <a href="https://wa.me/message/NJAV34FHKK47G1"><i class="bx bxl-whatsapp"></i></a>
            <a href="https://t.me/TopEngineerChat" class="telegram"><i class="bx bxl-telegram"></i></a>
            <a href="https://www.linkedin.com/company/top-engineer/" class="linkedin"><i
                    class="bx bxl-linkedin"></i></a>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\top-engineer\resources\views\frontend\include\footer.blade.php ENDPATH**/ ?>