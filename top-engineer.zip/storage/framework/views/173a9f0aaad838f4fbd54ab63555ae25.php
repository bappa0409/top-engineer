<nav id="sidebar" class="sidebar js-sidebar">
    <div class="sidebar-content js-simplebar">
        <a class="sidebar-brand" href="<?php echo e(route('admin.dashboard')); ?>">
            <span class="align-middle">Admin Panel</span>
        </a>

        <ul class="sidebar-nav">
            <li class="sidebar-item <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
                </a>
            </li>
            <li class="sidebar-item <?php echo e(request()->routeIs('admin.projects.index') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.projects.index')); ?>">
                    <i class="align-middle" data-feather="clipboard"></i> <span class="align-middle">Projects</span>
                </a>
            </li>
            <li class="sidebar-item <?php echo e(request()->routeIs('admin.contacts.index') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.contacts.index')); ?>">
                    <i class="align-middle" data-feather="message-square"></i> <span class="align-middle">Contact</span>
                </a>
            </li>

            <li class="sidebar-item <?php echo e(request()->routeIs('admin.profile.show') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.profile.show')); ?>">
                    <i class="align-middle" data-feather="settings"></i> <span class="align-middle">Profile Setting</span>
                </a>
            </li>
        </ul>

        <div class="sidebar-cta">
            <div class="sidebar-cta-content">
                <div class="d-grid">
                    <a href="<?php echo e(route('logout')); ?>" class="btn btn-primary" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="align-middle me-1" data-feather="log-out"></i>Log out
                        <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </a>
                </div>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\top-engineer\resources\views\include\sidebar.blade.php ENDPATH**/ ?>