<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                    Copyright © <a href="https://zaman-it.com/">Zaman IT</a>. All rights reserved.
                </p>
            </div>
        </div>
    </div>
</footer>
